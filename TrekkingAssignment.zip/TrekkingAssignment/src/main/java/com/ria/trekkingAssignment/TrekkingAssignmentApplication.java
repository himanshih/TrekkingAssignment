package com.ria.trekkingAssignment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrekkingAssignmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrekkingAssignmentApplication.class, args);
	}

}
