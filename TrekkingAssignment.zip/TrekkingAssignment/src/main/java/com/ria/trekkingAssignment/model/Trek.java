package com.ria.trekkingAssignment.model;

import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "trek")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Trek {

    @Id
    private String id;

    private String name;

    private String startAt;

    private String endAt;

    private int minimumAge;

    private int maximumAge;

    private double unitPrice;

}
