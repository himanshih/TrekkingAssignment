package com.ria.trekkingAssignment.service;

import com.ria.trekkingAssignment.model.Trek;
import com.ria.trekkingAssignment.payload.requests.TrekRequest;
import com.ria.trekkingAssignment.payload.response.TrekResponse;
import com.ria.trekkingAssignment.respository.TrekRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class TrekService {

    @Autowired
    TrekRepository trekRepository;

    public String addTrek(TrekRequest trekRequest) {

        Trek trek = Trek.builder()
                .name(trekRequest.getName())
                .startAt(trekRequest.getStartAt())
                .endAt(trekRequest.getEndAt())
                .minimumAge(trekRequest.getMinimumAge())
                .maximumAge(trekRequest.getMaximumAge())
                .unitPrice(trekRequest.getUnitPrice())
                .build();
        return trekRepository.save(trek).getId();
    }

    public List<TrekResponse> getAllTreks() {
        List<TrekResponse> trekResponseList = new ArrayList<>();
        List<Trek> trekList = trekRepository.findAll();
        for(Trek trek : trekList){
            TrekResponse trekResponse = new TrekResponse();
            trekResponse.setName(trek.getName());
            trekResponse.setUnitPrice(trek.getUnitPrice());
            trekResponseList.add(trekResponse);
        }
        return trekResponseList;
    }

}
