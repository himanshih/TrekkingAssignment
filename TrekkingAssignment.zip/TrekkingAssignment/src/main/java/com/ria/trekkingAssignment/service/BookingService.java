package com.ria.trekkingAssignment.service;

import com.ria.trekkingAssignment.model.Booking;
import com.ria.trekkingAssignment.model.Trek;
import com.ria.trekkingAssignment.payload.requests.BookingRequest;
import com.ria.trekkingAssignment.payload.response.BookingResponse;
import com.ria.trekkingAssignment.respository.BookingRepository;
import com.ria.trekkingAssignment.respository.TrekRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class BookingService {
    BookingRepository bookingRepository;
    TrekRepository trekRepository;
    public BookingService(@Autowired BookingRepository bookingRepository, @Autowired TrekRepository trekRepository) {
        this.bookingRepository = bookingRepository;
        this.trekRepository = trekRepository;
    }

    public String addBooking(BookingRequest bookingRequest) {
        Trek trek = trekRepository.findByName(bookingRequest.getTrekName());
        if(trek == null)
            return "Trek not found";
        if(bookingRequest.getAge() > trek.getMaximumAge() || bookingRequest.getAge() < trek.getMinimumAge())
            return "Age not eligible for trek";
        Booking booking = Booking.builder()
                .name(bookingRequest.getName())
                .age(bookingRequest.getAge())
                .trekName(bookingRequest.getTrekName())
                .build();

        return bookingRepository.save(booking).getId();
    }

    public  List<BookingResponse> getAllBookings() {
        List<BookingResponse> bookingResponseList = new ArrayList<>();
        List<Booking> bookingList = bookingRepository.findAll();
        for(Booking booking : bookingList){
            BookingResponse bookingResponse = new BookingResponse();
            bookingResponse.setName(booking.getName());
            bookingResponse.setTrekName(booking.getTrekName());
            bookingResponseList.add(bookingResponse);
        }
        return bookingResponseList;
    }

}
