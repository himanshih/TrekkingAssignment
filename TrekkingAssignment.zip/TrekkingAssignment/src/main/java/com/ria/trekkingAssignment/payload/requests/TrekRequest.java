package com.ria.trekkingAssignment.payload.requests;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class TrekRequest {

    private String name;

    private String startAt;

    private String endAt;

    private int minimumAge;

    private int maximumAge;

    private double unitPrice;

}
