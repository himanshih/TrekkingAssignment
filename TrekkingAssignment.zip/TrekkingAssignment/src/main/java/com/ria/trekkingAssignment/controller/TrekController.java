package com.ria.trekkingAssignment.controller;

import com.ria.trekkingAssignment.payload.requests.TrekRequest;
import com.ria.trekkingAssignment.payload.response.TrekResponse;
import com.ria.trekkingAssignment.service.TrekService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/trek")
public class TrekController {

    @Autowired
    TrekService trekService;

    @PostMapping
    public ResponseEntity<String> addTrek(@RequestBody TrekRequest trekRequest) {
        return ResponseEntity.ok(trekService.addTrek(trekRequest));
    }

    @GetMapping
    public ResponseEntity<List<TrekResponse>> getTreks() {
        return ResponseEntity.ok(trekService.getAllTreks());
    }

}
