package com.ria.trekkingAssignment.controller;

import com.ria.trekkingAssignment.payload.requests.BookingRequest;
import com.ria.trekkingAssignment.payload.response.BookingResponse;
import com.ria.trekkingAssignment.service.BookingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/booking")
public class BookingController {

    @Autowired
    BookingService bookingService;

    @PostMapping
    public ResponseEntity<String> addBooking(@RequestBody BookingRequest bookingRequest) {
        return ResponseEntity.ok(bookingService.addBooking(bookingRequest));
    }

    @GetMapping
    public ResponseEntity<List<BookingResponse>> getBookings() {
        return ResponseEntity.ok(bookingService.getAllBookings());
    }

}
