package com.ria.trekkingAssignment;

import com.ria.trekkingAssignment.model.Booking;
import com.ria.trekkingAssignment.model.Trek;
import com.ria.trekkingAssignment.payload.requests.BookingRequest;
import com.ria.trekkingAssignment.respository.BookingRepository;
import com.ria.trekkingAssignment.respository.TrekRepository;
import com.ria.trekkingAssignment.service.BookingService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class TrekkingAssignmentApplicationTests {

	@Mock
	BookingRepository mockBookingRepository;

	@Mock
	TrekRepository mockTrekRepository;

	BookingService bookingService;

	Trek mockTrek;

	Booking mockBooking;

	@BeforeEach
	void init() {
		bookingService = new BookingService(mockBookingRepository, mockTrekRepository);
		mockTrek = Trek.builder()
				.id("mockTrekId")
				.name("mockTrek")
				.unitPrice(2230)
				.minimumAge(18)
				.maximumAge(80)
				.build();
		mockBooking = Booking.builder()
				.id("bookingId")
				.age(20)
				.name("Test")
				.trekName("mockTrek")
				.build();
	}

	@Test
	void returnInvalidTrekMessageIfTrekRequestedInBookingIsInvalid() {
		BookingRequest bookingRequest = new BookingRequest();
		bookingRequest.setName("Test");
		bookingRequest.setAge(35);
		bookingRequest.setTrekName("Invalid Trek");
		when(mockTrekRepository.findByName(bookingRequest.getTrekName())).thenReturn(null);
		assertEquals(bookingService.addBooking(bookingRequest), "Trek not found");
	}



}